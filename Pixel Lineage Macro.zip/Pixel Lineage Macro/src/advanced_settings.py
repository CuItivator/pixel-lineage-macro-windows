from __future__ import annotations

DEFAULT_ADVANCED: dict[str, float] = {
    "press_lead_s": 0.035,
    "aim_bias": 0.0,
    "min_speed": 0.12,
    "press_hold_s": 0.03,
    "meter_lead_s": 0.05,
    "lock_delay_s": 0.0,
    "early_gap_sec": 0.35,
    "minigame_lost_s": 0.6,
    "minigame_max_s": 8.0,
    "minigame_block_sec": 3.0,
    "poll_sec": 0.02,
    "key_hold_sec": 0.06,
    "battle_space_sec": 0.15,
    "skill_space_sec": 0.45,
    "stuck_fix_sec": 3.0,
    "wait_space_sec": 0.5,
    "victory_gap_sec": 0.35,
    "victory_max_sec": 15.0,
    "skill_wait_sec": 0.45,
    "skill_retry_sec": 8.0,
    "chest_check_sec": 1.5,
    "label_read_sec": 0.5,
    "path_settle_sec": 0.6,
    "after_pick_sec": 1.2,
    "option_wait_sec": 0.9,
    "stuck_alert_sec": 180.0,
    "mouse_nudge_mid_sec": 0.01,
    "mouse_nudge_settle_sec": 0.04,
    "mouse_click_hold_sec": 0.04,
}

ADVANCED_SECTIONS: list[tuple[str, list[tuple[str, str, str]]]] = [
    (
        "Minigames",
        [
            ("press_lead_s", "Press timing (sec)",
             "How early it presses before the marker reaches the middle of the zone, raise it if it keeps stopping past the zone, lower it if it stops before (on the blue at the near edge)"),
            ("aim_bias", "Aim bias (zone widths)",
             "0 aims at the middle of the white zone, positive aims further along the way the marker is going, negative aims earlier"),
            ("min_speed", "Min marker speed",
             "The marker has to move at least this many bar widths a second before it presses, stops it from pressing on a marker that hasn't started yet"),
            ("meter_lead_s", "Meter timing (sec)",
             "Fist and Archer, how early it presses before the power reaches the middle of the gold band, raise it if it stops above the middle, lower it if it stops below"),
            ("lock_delay_s", "Gold lock delay (sec)",
             "Mage and Thief, waits this long after the frame turns gold before pressing, 0 presses right away (that's a PERFECT)"),
            ("early_gap_sec", "Early Mode gap (sec)",
             "With Early Mode on it presses Space this often while the attack minigame is up"),
            ("press_hold_s", "Press hold (sec)",
             "How long Space stays down for each minigame press"),
            ("minigame_lost_s", "Minigame gone (sec)",
             "Once the minigame is gone this long it stops playing and goes back to Space, if it is still there it just picks it up again on the next look"),
            ("minigame_max_s", "Minigame max (sec)",
             "Gives up on a minigame after this long"),
            ("minigame_block_sec", "Ignore stuck minigame (sec)",
             "If a minigame hits the max and is still on screen, it stops playing it for this long and goes back to pressing Space to push it along"),
        ],
    ),
    (
        "Battle",
        [
            ("poll_sec", "Screen check every (sec)",
             "Pause between screen checks, this is how fast it spots a minigame starting, leave it low"),
            ("key_hold_sec", "Key hold (sec)",
             "How long Space stays down when it attacks, picks a foe, opens a chest or presses CONTINUE"),
            ("battle_space_sec", "Battle Space every (sec)",
             "In a fight with no minigame on screen it presses Space this often, it never presses while a minigame box is up so it can't ruin a dodge"),
            ("skill_space_sec", "Battle Space with a skill (sec)",
             "The same gap but for when Use a skill is on, it is slower on purpose so every turn gets read before it attacks"),
            ("stuck_fix_sec", "Menu stuck (sec)",
             "If your command menu or CHOOSE A FOE is still up after this long it nudges the mouse back onto ATTACK, then clicks, then clicks BACK"),
            ("wait_space_sec", "Waiting Space every (sec)",
             "Outside a fight, with nothing to click, it presses Space this often to get through dialogs"),
            ("victory_gap_sec", "VICTORY Space gap (sec)",
             "Once the VICTORY banner shows up it presses Space this often until the Choose Your Path screen appears"),
            ("victory_max_sec", "VICTORY give up (sec)",
             "How long it keeps pressing Space after a VICTORY before it goes back to the normal waiting Space"),
            ("skill_wait_sec", "Skill menu wait (sec)",
             "Wait after opening Skills before it reads the skill list"),
            ("skill_retry_sec", "Skill retry (sec)",
             "How long it waits after going for a skill before it goes for one again"),
            ("chest_check_sec", "Chest check every (sec)",
             "How often it looks for CLICK TO OPEN! when it's not in a fight, it opens chests with Space"),
            ("label_read_sec", "Button label reread (sec)",
             "How long it trusts the words it read on a gold button before reading them again"),
        ],
    ),
    (
        "Choose your path",
        [
            ("path_settle_sec", "Path settle (sec)",
             "Wait after the Choose Your Path screen shows up before it reads the paths, raise it if it reads them while they're still sliding in"),
            ("after_pick_sec", "After pick (sec)",
             "Wait after clicking a path or TO BATTLE!"),
            ("option_wait_sec", "Choice wait (sec)",
             "Wait after clicking a choice in an event before it checks TO BATTLE! again"),
        ],
    ),
    (
        "Mouse click feel",
        [
            ("mouse_nudge_mid_sec", "Move nudge mid (sec)",
             "Timing for the little cursor nudge so Roblox actually registers the click"),
            ("mouse_nudge_settle_sec", "Move settle (sec)",
             "How long it waits after moving the cursor before clicking"),
            ("mouse_click_hold_sec", "Click hold (sec)",
             "How long a click stays down"),
        ],
    ),
    (
        "Webhook",
        [
            ("stuck_alert_sec", "Stuck alert (sec)",
             "Pings you if nothing happens for this long"),
        ],
    ),
]


def merge_advanced(raw: dict | None) -> dict[str, float]:
    out = dict(DEFAULT_ADVANCED)
    if isinstance(raw, dict):
        for k, v in raw.items():
            if k in out:
                try:
                    out[k] = float(v)
                except (TypeError, ValueError):
                    pass
    return out
